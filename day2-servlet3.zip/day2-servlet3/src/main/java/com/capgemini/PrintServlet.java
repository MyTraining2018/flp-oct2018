package com.capgemini;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class PrintServlet
 */
@WebServlet("/PrintServlet")
public class PrintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
		
		HttpSession session=request.getSession(false);
		String userName=session.getAttribute("user").toString();
		response.getWriter().println("<h1 styles='color:red;'>Hello! " + userName +"</h1>");
		
		Cookie[] cookies= request.getCookies();
		if(cookies!=null) {
			for(Cookie cookie:cookies) {
				response.getWriter().println("key-->"+cookie.getName() +"&nbsp;&nbsp;&nbsp;&nbsp;"
						+"Value---->" + cookie.getValue() +"<br>");
			}
		}
		
		response.setContentType("text/html");
		response.getWriter().println("Your Message.");
		response.getWriter().println("Message:" + request.getParameter("msg"));
	}

}
