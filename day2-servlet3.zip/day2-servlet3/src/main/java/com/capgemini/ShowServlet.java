package com.capgemini;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShowServlet
 */
@WebServlet("/ShowServlet")
public class ShowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String msg=request.getParameter("msg");
		
		HttpSession session=request.getSession();
		session.setAttribute("user", "Tom");
		
		
		
		
		Cookie cookie1=new Cookie("fruit", "apple");
		response.addCookie(cookie1);
		
		Cookie cookie2=new Cookie("Product", "Samsung");
		//cookie2.setMaxAge(1);
		response.addCookie(cookie2);
		
		
		Cookie[] cookies= request.getCookies();
		if(cookies!=null) {
			for(Cookie cookie:cookies) {
				response.getWriter().println("key-->"+cookie.getName() +"&nbsp;&nbsp;&nbsp;&nbsp;"
						+"Value---->" + cookie.getValue() +"<br>");
			}
		}
		String greet=request.getParameter("greet");
		String empPwd=request.getParameter("empPwd");
		response.getWriter().println("Message:" + msg + "<br>");
		response.getWriter().println("Greet:" + greet + "<br>");
		response.getWriter().println("Password:" + empPwd + "<br>");
		response.getWriter().println("<a href='PrintServlet?msg="+msg+"'>Show Message Again!</a>");
	}

}
