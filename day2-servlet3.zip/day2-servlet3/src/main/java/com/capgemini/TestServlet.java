package com.capgemini;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns="/TestServlet",loadOnStartup=1)
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String driverClassName,userName,userPwd;
	ServletContext context;
	ServletConfig config;
	@Override
	public void init() throws ServletException {
		context=getServletContext();
		config=getServletConfig();
		driverClassName=config.getInitParameter("driverClass");
		userName=config.getInitParameter("userName");
		userPwd=config.getInitParameter("passwd");
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
	

		
		HttpSession session=request.getSession(false);
		String userName=session.getAttribute("user").toString();
		response.getWriter().println("<h1 styles='color:red;'>Hello! " + userName +"</h1>");
		
		String email=context.getInitParameter("email");
		response.getWriter().println("<h1>Email:" + email + "</h1>");
		
		String greet=context.getInitParameter("greetings");
		response.getWriter().println("<h1>Greeings:" + greet + "</h1>");
		response.getWriter().println("<h1>DriverClass:" + driverClassName + "</h1>");
		response.getWriter().println("<h1>USer:" + userName + "</h1>");
		response.getWriter().println("<h1>Password:" + userPwd + "</h1>");
		
		response.getWriter().println("<a href='Logout'> LogOUt</a>");
	}

}
